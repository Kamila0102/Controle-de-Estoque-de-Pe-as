// Simulando banco de dados com localStorage
const USUARIO_PADRAO = {
  usuario: "KamilaMarcon",
  senha: "1234"
};

function fazerLogin() {
  const usuario = document.getElementById("usuario").value;
  const senha = document.getElementById("senha").value;
  const erro = document.getElementById("mensagemErro");

  if (usuario === USUARIO_PADRAO.usuario && senha === USUARIO_PADRAO.senha) {
    window.location.href = "dashboard.html";
  } else {
    erro.textContent = "Usuário ou senha incorretos.";
  }
}

function salvarCodigo() {
  const codigo = document.getElementById("codigo").value;
  let codigos = JSON.parse(localStorage.getItem("codigos") || "[]");

  if (codigo.trim() === "") {
    document.getElementById("mensagemCodigo").textContent = "Código inválido!";
    return;
  }

  codigos.push(codigo);
  localStorage.setItem("codigos", JSON.stringify(codigos));
  document.getElementById("mensagemCodigo").textContent = "Código salvo!";
}

/*
function cadastrarProduto() {
  const nome = document.getElementById("nomeProduto").value;
  const categoria = document.getElementById("categoriaProduto").value;
  const quantidade = document.getElementById("quantidadeProduto").value;
  const codigo = document.getElementById("codigoProduto").value;

  const codigos = JSON.parse(localStorage.getItem("codigos") || "[]");
  if (!codigos.includes(codigo)) {
    document.getElementById("mensagemProduto").textContent = "Código não encontrado!";
    return;
  }

  let produtos = JSON.parse(localStorage.getItem("produtos") || "[]");
  produtos.push({ nome, categoria, quantidade, codigo });
  localStorage.setItem("produtos", JSON.stringify(produtos));
  document.getElementById("mensagemProduto").textContent = "Produto cadastrado com sucesso!";
}

function exibirProdutos() {
  const lista = document.getElementById("listaProdutos");
  const produtos = JSON.parse(localStorage.getItem("produtos") || "[]");

  lista.innerHTML = "";

  produtos.forEach((p) => {
    const item = document.createElement("li");
    item.textContent = `${p.nome} - ${p.categoria} - Qtd: ${p.quantidade} - Código: ${p.codigo}`;
    lista.appendChild(item);
  });
}
*/

function cadastrarProduto() {
  const nome = document.getElementById("nomeProduto").value;
  const categoria = document.getElementById("categoriaProduto").value;
  const quantidade = document.getElementById("quantidadeProduto").value;
  const codigo = document.getElementById("codigoProduto").value;
  const valor = document.getElementById("valorProduto").value;

  const codigos = JSON.parse(localStorage.getItem("codigos") || "[]");
  if (!codigos.includes(codigo)) {
    document.getElementById("mensagemProduto").textContent = "Código não encontrado!";
    return;
  }

  let produtos = JSON.parse(localStorage.getItem("produtos") || "[]");
  produtos.push({ nome, categoria, quantidade, codigo, valor });
  localStorage.setItem("produtos", JSON.stringify(produtos));
  document.getElementById("mensagemProduto").textContent = "Produto cadastrado com sucesso!";
}

function exibirProdutos() {
  const lista = document.getElementById("listaProdutos");
  const produtos = JSON.parse(localStorage.getItem("produtos") || "[]");

  lista.innerHTML = "";

  produtos.forEach((p, index) => {
    const item = document.createElement("li");
    item.innerHTML = `
      <strong>${p.nome}</strong> - ${p.categoria} <br>
      Código: ${p.codigo} <br>
      Qtd: ${p.quantidade} 
      <button onclick="editarQuantidade(${index})">Alterar Qtd</button><br>
      Valor: R$ ${parseFloat(p.valor).toFixed(2)} 
      <button onclick="editarValor(${index})">Alterar Valor</button><br>
      <button onclick="excluirProduto(${index})">Excluir</button>
      <hr>
    `;
    lista.appendChild(item);
  });
}



function editarQuantidade(index) {
  const novaQtd = prompt("Digite a nova quantidade:");
  if (novaQtd !== null && !isNaN(novaQtd)) {
    let produtos = JSON.parse(localStorage.getItem("produtos") || "[]");
    produtos[index].quantidade = parseInt(novaQtd);
    localStorage.setItem("produtos", JSON.stringify(produtos));
    exibirProdutos();
  }
}

function excluirProduto(index) {
  if (confirm("Tem certeza que deseja excluir este produto?")) {
    let produtos = JSON.parse(localStorage.getItem("produtos") || "[]");
    produtos.splice(index, 1);
    localStorage.setItem("produtos", JSON.stringify(produtos));
    exibirProdutos();
  }
}


function exibirCodigos() {
  const lista = document.getElementById("listaCodigos");
  const codigos = JSON.parse(localStorage.getItem("codigos") || "[]");
  const produtos = JSON.parse(localStorage.getItem("produtos") || "[]");

  lista.innerHTML = "";

  codigos.forEach((codigo) => {
    // Verificar se algum produto usa esse código
    const produto = produtos.find(p => p.codigo === codigo);
    const nomeProduto = produto ? produto.nome : "<em>Não vinculado</em>";

    const item = document.createElement("li");
    item.innerHTML = `<strong>${codigo}</strong> → ${nomeProduto}`;
    lista.appendChild(item);
  });
}


function editarValor(index) {
  const novoValor = prompt("Digite o novo valor (apenas números):");
  if (novoValor !== null && !isNaN(novoValor)) {
    let produtos = JSON.parse(localStorage.getItem("produtos") || "[]");
    produtos[index].valor = parseFloat(novoValor).toFixed(2);
    localStorage.setItem("produtos", JSON.stringify(produtos));
    exibirProdutos();
  }
}
